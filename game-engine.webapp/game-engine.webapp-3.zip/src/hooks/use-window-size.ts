import {useEffect, useState} from "react";

export function useWindowSize() {

    const [size, setSize] = useState({
        width:window.innerWidth,
        height:window.innerHeight
    })

    const updateSize = () => {
        setSize({
            width: window.innerWidth,
            height: window.innerHeight
        })
    }

    useEffect(() => {
        window.addEventListener("resize", updateSize)
        return ()=>{
            window.removeEventListener("resize", updateSize)
        }
    }, [window.innerWidth]);

    return size

}